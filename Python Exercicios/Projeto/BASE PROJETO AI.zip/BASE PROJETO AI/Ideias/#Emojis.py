#site com os codigos de emojis
#https://emojiterra.com/pt/pontos-de-codigo/
print("Eu consegui")
print("\U0001F604")
input("ENTER para terminar")